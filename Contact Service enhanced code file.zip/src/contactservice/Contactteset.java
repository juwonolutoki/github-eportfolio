package contactservice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    public void testCreateContact() {
        Contact contact = new Contact("001", "John", "Doe", "1234567890", "123 Main St");

        assertEquals("001", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("002", "Jane", "Smith", "9876543210", "456 Elm St");

        contact.setFirstName("Alice");
        contact.setLastName("Johnson");
        contact.setPhone("5555555555");
        contact.setAddress("789 Oak Ave");

        assertEquals("Alice", contact.getFirstName());
        assertEquals("Johnson", contact.getLastName());
        assertEquals("5555555555", contact.getPhone());
        assertEquals("789 Oak Ave", contact.getAddress());
    }

    // Add additional tests for length constraints, null checks, etc.
}
