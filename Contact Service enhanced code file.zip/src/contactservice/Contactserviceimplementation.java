package contactservice;

import java.util.HashMap;
import java.util.Map;

public class ContactServiceImpl implements ContactService {
    private Map<String, Contact> contacts = new HashMap<>();

    @Override
    public void addContact(Contact contact) {
        contacts.put(contact.getContactId(), contact);
    }

    @Override
    public void deleteContact(String contactId) {
        contacts.remove(contactId);
    }

    @Override
    public void updateFirstName(String contactId, String newFirstName) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setFirstName(newFirstName);
        }
    }

    @Override
    public void updateLastName(String contactId, String newLastName) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setLastName(newLastName);
        }
    }

    @Override
    public void updatePhone(String contactId, String newPhone) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setPhone(newPhone);
        }
    }

    @Override
    public void updateAddress(String contactId, String newAddress) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setAddress(newAddress);
        }
    }

    @Override
    public Contact getContactById(String contactId) {
        return contacts.get(contactId);
    }
}

