public class Task {
    private final String id; // Unique and immutable task ID
    private String name; // Name of the task
    private String description; // Description of the task

    // Constructor
    public Task(String id, String name, String description) {
        if (id == null || id.length() > 10) {
            throw new IllegalArgumentException("Task ID cannot be null or longer than 10 characters.");
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Task name cannot be null or longer than 20 characters.");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Task description cannot be null or longer than 50 characters.");
        }
        this.id = id;
        this.name = name;
        this.description = description;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // Setters (for updatable fields)
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Task name cannot be null or longer than 20 characters.");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Task description cannot be null or longer than 50 characters.");
        }
        this.description = description;
    }
}
